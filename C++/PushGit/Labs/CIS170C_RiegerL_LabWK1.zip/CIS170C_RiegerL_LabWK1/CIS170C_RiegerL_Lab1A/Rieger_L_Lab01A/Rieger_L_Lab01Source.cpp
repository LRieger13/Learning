
// ---------------------------------------------------------------
// Programming Assignment:	LAB1A
// Developer:			Leah Rieger
// Date Written:		07/10/2019
// Purpose:				Ticket Calculation Program 
// ---------------------------------------------------------------
#include <iostream>

using namespace std;

void main()
{

	cout << "Leah Rieger ticket program\n";

	int childTkts, adultTkts, totalTkts;
	cout << "Please enter the number of child tickets:";
	cin >> childTkts;
	cout << "Please enter the number of adult tickets:";
	cin >> adultTkts;
	totalTkts = childTkts + adultTkts;

	cout << "The total tickets are: " << totalTkts << endl;



}

