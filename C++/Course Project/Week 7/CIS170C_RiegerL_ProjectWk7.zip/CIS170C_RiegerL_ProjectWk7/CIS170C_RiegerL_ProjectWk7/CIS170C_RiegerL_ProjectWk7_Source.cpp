// ---------------------------------------------------------------
// Programming Assignment:	Course Project
// Developer:			Leah Rieger
// Date Written:		08/23/2019
// Purpose:				Programming Tutorial Program 
// ---------------------------------------------------------------

#include <iostream>
#include <string>
#include <cstdlib>
#include "Project.h"


using namespace std;



int main() {

	MyClass program;
	program.mainMenu();


	return 0;
	system("pause");
}
